import hello

print hello.sayhello()

