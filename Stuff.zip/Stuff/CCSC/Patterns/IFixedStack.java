public interface IFixedStack {
    void push(Object o);
    Object pop();
    Object top();
    int size();
}
