#include "ctest.h"

int main() {
    int x = 1;
    test(x == 1);
    report();
}
