// split.h

#ifndef SPLIT_H
#define SPLIT_H

long split(double, double&);

#endif

