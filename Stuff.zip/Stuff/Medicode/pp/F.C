#define F(f) f(args)
#define args a,b

F(g)
F(F)
